--
-- phpwind SQL Dump
-- version:9.0
-- time: 2013-05-24 10:24
-- tablepre: aim_
-- phpwind: http://www.phpwind.net
-- --------------------------------------------------------


DROP TABLE IF EXISTS `aim_common_config`;
CREATE TABLE `aim_common_config` (
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `namespace` varchar(15) NOT NULL DEFAULT 'global' COMMENT '配置命名空间',
  `value` text COMMENT '缓存值',
  `vtype` enum('string','array','object') NOT NULL DEFAULT 'string' COMMENT '配置值类型',
  `description` text COMMENT '配置介绍',
  PRIMARY KEY (`namespace`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='网站配置表';

INSERT INTO aim_common_config VALUES('extsize','attachment','a:11:{s:3:\"jpg\";i:2048;s:3:\"gif\";i:2048;s:3:\"png\";i:2048;s:3:\"bmp\";i:2048;s:3:\"xls\";i:2048;s:3:\"txt\";i:2048;s:3:\"doc\";i:2048;s:4:\"docx\";i:2048;s:3:\"rar\";i:2048;s:3:\"zip\";i:2048;s:3:\"pdf\";i:2048;}','array','');
INSERT INTO aim_common_config VALUES('mark.file','attachment','logo.gif','string','');
INSERT INTO aim_common_config VALUES('mark.fontcolor','attachment','#000000','string','');
INSERT INTO aim_common_config VALUES('mark.fontfamily','attachment','en_arial.ttf','string','');
INSERT INTO aim_common_config VALUES('mark.fontsize','attachment','5','string','');
INSERT INTO aim_common_config VALUES('mark.gif','attachment','0','string','');
INSERT INTO aim_common_config VALUES('mark.limitheight','attachment','50','string','');
INSERT INTO aim_common_config VALUES('mark.limitwidth','attachment','100','string','');
INSERT INTO aim_common_config VALUES('mark.markset','attachment','a:4:{i:0;s:3:\"bbs\";i:1;s:5:\"album\";i:2;s:5:\"diary\";i:3;s:3:\"cms\";}','array','');
INSERT INTO aim_common_config VALUES('mark.position','attachment','9','string','');
INSERT INTO aim_common_config VALUES('mark.quality','attachment','90','string','');
INSERT INTO aim_common_config VALUES('mark.text','attachment','phpwind','string','');
INSERT INTO aim_common_config VALUES('mark.transparency','attachment','90','string','');
INSERT INTO aim_common_config VALUES('mark.type','attachment','2','string','');
INSERT INTO aim_common_config VALUES('pathsize','attachment','2048','string','');
INSERT INTO aim_common_config VALUES('thumb','attachment','1','string','');
INSERT INTO aim_common_config VALUES('thumb.quality','attachment','90','string','');
INSERT INTO aim_common_config VALUES('thumb.size.height','attachment','','string','');
INSERT INTO aim_common_config VALUES('thumb.size.width','attachment','500','string','');
INSERT INTO aim_common_config VALUES('content.length.max','bbs','5000','string','');
INSERT INTO aim_common_config VALUES('content.length.min','bbs','3','string','');
INSERT INTO aim_common_config VALUES('post.check.end_hour','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.check.end_min','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.check.groups','bbs','a:3:{i:0;s:1:\"3\";i:1;s:1:\"4\";i:2;s:1:\"5\";}','array','');
INSERT INTO aim_common_config VALUES('post.check.open','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.check.start_hour','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.check.start_min','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.timing.end_hour','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.timing.end_min','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.timing.groups','bbs','a:11:{i:0;s:1:\"7\";i:1;s:1:\"8\";i:2;s:1:\"9\";i:3;s:2:\"10\";i:4;s:2:\"11\";i:5;s:2:\"12\";i:6;s:2:\"13\";i:7;s:2:\"14\";i:8;s:1:\"3\";i:9;s:1:\"4\";i:10;s:1:\"5\";}','array','');
INSERT INTO aim_common_config VALUES('post.timing.open','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.timing.start_hour','bbs','0','string','');
INSERT INTO aim_common_config VALUES('post.timing.start_min','bbs','0','string','');
INSERT INTO aim_common_config VALUES('read.anoymous_displayname','bbs','','string','');
INSERT INTO aim_common_config VALUES('read.defined_floor_name','bbs','0:楼主\n1:沙发\n2:板凳\n3:地板','string','');
INSERT INTO aim_common_config VALUES('read.display_info','bbs','a:4:{s:3:\"uid\";i:1;s:4:\"fans\";i:1;s:7:\"follows\";i:1;s:5:\"posts\";i:1;}','array','');
INSERT INTO aim_common_config VALUES('read.display_info_vieworder','bbs','a:12:{s:3:\"uid\";i:0;s:7:\"regdate\";i:1;s:9:\"lastvisit\";i:2;s:4:\"fans\";i:3;s:7:\"follows\";i:4;s:5:\"posts\";i:5;s:8:\"homepage\";i:6;s:8:\"location\";i:7;s:2:\"qq\";i:8;s:5:\"aliww\";i:9;s:8:\"birthday\";i:10;s:8:\"hometown\";i:11;}','array','');
INSERT INTO aim_common_config VALUES('read.display_member_info','bbs','1','string','');
INSERT INTO aim_common_config VALUES('read.floor_name','bbs','�\�','string','');
INSERT INTO aim_common_config VALUES('read.perpage','bbs','15','string','');
INSERT INTO aim_common_config VALUES('read.shield_banthreads','bbs','1','string','');
INSERT INTO aim_common_config VALUES('thread.hotthread_replies','bbs','3','string','');
INSERT INTO aim_common_config VALUES('thread.leftside_width','bbs','','string','');
INSERT INTO aim_common_config VALUES('thread.max_pages','bbs','1000','string','');
INSERT INTO aim_common_config VALUES('thread.new_thread_minutes','bbs','20','string','');
INSERT INTO aim_common_config VALUES('thread.perpage','bbs','20','string','');
INSERT INTO aim_common_config VALUES('title.length.max','bbs','100','string','');
INSERT INTO aim_common_config VALUES('credits','credit','a:6:{i:1;a:4:{s:4:\"name\";s:6:\"铜币\";s:4:\"unit\";s:3:\"�\�\";s:4:\"open\";s:1:\"1\";s:3:\"log\";s:1:\"1\";}i:2;a:4:{s:4:\"name\";s:6:\"威望\";s:4:\"unit\";s:3:\"�\�\";s:4:\"open\";s:1:\"1\";s:3:\"log\";s:1:\"1\";}i:3;a:4:{s:4:\"name\";s:6:\"银元\";s:4:\"unit\";s:3:\"�\�\";s:4:\"open\";s:1:\"1\";s:3:\"log\";s:1:\"1\";}i:4;a:2:{s:4:\"name\";s:6:\"贡献\";s:4:\"unit\";s:3:\"�\�\";}i:5;a:2:{s:4:\"name\";s:6:\"鸡蛋\";s:4:\"unit\";s:3:\"�\�\";}i:6;a:2:{s:4:\"name\";s:6:\"鲜花\";s:4:\"unit\";s:3:\"�\�\";}}','array','');
INSERT INTO aim_common_config VALUES('strategy','credit','a:13:{i:0;s:0:\"\";s:8:\"register\";a:2:{s:5:\"limit\";s:1:\"1\";s:6:\"credit\";a:4:{i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:5:\"login\";a:2:{s:5:\"limit\";s:1:\"1\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"2\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:7:\"sendmsg\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:10:\"post_topic\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"2\";i:2;s:1:\"2\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:12:\"delete_topic\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:2:\"-2\";i:2;s:2:\"-2\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:10:\"post_reply\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"1\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:12:\"delete_reply\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:2:\"-1\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:12:\"digest_topic\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:13:\"remove_digest\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:3:\"-10\";i:2;s:3:\"-10\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:10:\"upload_att\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:12:\"download_att\";a:2:{s:5:\"limit\";s:1:\"0\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}s:6:\"belike\";a:2:{s:5:\"limit\";s:2:\"10\";s:6:\"credit\";a:4:{i:1;s:1:\"0\";i:2;s:1:\"1\";i:3;s:1:\"0\";i:4;s:1:\"0\";}}}','array','');
INSERT INTO aim_common_config VALUES('upgradestrategy','site','a:3:{s:7:\"credit1\";s:1:\"1\";s:7:\"credit2\";s:1:\"1\";s:7:\"postnum\";s:1:\"1\";}','array','');
INSERT INTO aim_common_config VALUES('question.groups','login','','string','');
INSERT INTO aim_common_config VALUES('resetpwd.mail.content','login','尊敬的{username}，这是来自{sitename}的密码重置邮件�\�\n点击下面的链接重置您的密码：<br/>\n{url}<br/>\n如果链接无法点击，请将链接粘贴到浏览器的地址栏中访问�\�<br/>\n{sitename} <br/>\n{time}','string','');
INSERT INTO aim_common_config VALUES('resetpwd.mail.title','login','{username}您好，这是{sitename}发送给您的密码重置邮件','string','');
INSERT INTO aim_common_config VALUES('trypwd','login','5','string','');
INSERT INTO aim_common_config VALUES('ways','login','a:1:{i:0;s:1:\"3\";}','array','');
INSERT INTO aim_common_config VALUES('active.check','register','0','string','');
INSERT INTO aim_common_config VALUES('active.field','register','','string','');
INSERT INTO aim_common_config VALUES('active.mail','register','0','string','');
INSERT INTO aim_common_config VALUES('active.mail.content','register','尊敬的{username}�\�\n<br/>欢迎你注册成为{sitename}的会员！\n<br/>请点击下面的链接进行帐号的激活：\n<br/>{url}\n<br/>如果不能点击链接，请复制到浏览器地址输入框访问�\�\n<br/>\n<br/>{sitename}\n<br/>{time}','string','');
INSERT INTO aim_common_config VALUES('active.mail.title','register','来自{sitename}的注册激活邮�\�','string','');
INSERT INTO aim_common_config VALUES('active.phone','register','0','string','');
INSERT INTO aim_common_config VALUES('close.msg','register','<h1>暂时关闭注册</h1>','string','');
INSERT INTO aim_common_config VALUES('invite.credit.type','register','1','string','');
INSERT INTO aim_common_config VALUES('invite.expired','register','30','string','');
INSERT INTO aim_common_config VALUES('invite.pay.money','register','','string','');
INSERT INTO aim_common_config VALUES('invite.pay.open','register','0','string','');
INSERT INTO aim_common_config VALUES('invite.reward.credit.num','register','10','string','');
INSERT INTO aim_common_config VALUES('invite.reward.credit.type','register','2','string','');
INSERT INTO aim_common_config VALUES('protocol','register','当您申请用户时，表示您已经同意遵守本规章�\� 欢迎您加入本站点参加交流和讨论，本站点为公共论坛，为维护网上公共秩序和社会稳定，请您自觉遵守以下条款�\� <br>\n一、不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益，不得利用本站制作、复制和传播下列信息�\� <br>\n（一）煽动抗拒、破坏宪法和法律、行政法规实施的�\�\n（二）煽动颠覆国家政权，推翻社会主义制度的；<br>\n（三）煽动分裂国家、破坏国家统一的；<br>\n（四）煽动民族仇恨、民族歧视，破坏民族团结的；<br>\n（五）捏造或者歪曲事实，散布谣言，扰乱社会秩序的�\�<br>\n（六）宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的�\�<br>\n（七）公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的�\�<br>\n（八）损害国家机关信誉的�\�<br>\n（九）其他违反宪法和法律行政法规的；<br>\n（十）进行商业广告行为的�\�<br>\n二、互相尊重，对自己的言论和行为负责�\�<br>\n三、禁止在申请用户时使用相关本站的词汇，或是带有侮辱、毁谤、造谣类的或是有其含义的各种语言进行注册用户，否则我们会将其删除�\�<br>\n四、禁止以任何方式对本站进行各种破坏行为�\�<br>\n五、如果您有违反国家相关法律法规的行为，本站概不负责，您的登录论坛信息均被记录无疑，必要时，我们会向相关的国家管理部门提供此类信息�\� ','string','');
INSERT INTO aim_common_config VALUES('security.ban.username','register','创始�\�,管理�\�,版主,斑竹,admin','string','');
INSERT INTO aim_common_config VALUES('security.ip','register','0','string','');
INSERT INTO aim_common_config VALUES('security.password','register','','string','');
INSERT INTO aim_common_config VALUES('security.password.max','register','15','string','');
INSERT INTO aim_common_config VALUES('security.password.min','register','6','string','');
INSERT INTO aim_common_config VALUES('security.username.max','register','15','string','');
INSERT INTO aim_common_config VALUES('security.username.min','register','3','string','');
INSERT INTO aim_common_config VALUES('type','register','1','string','');
INSERT INTO aim_common_config VALUES('welcome.content','register','尊敬的{username}�\�\n<br/>欢迎你注册成为{sitename}的会员！\n<br/>\n<br/>本站全体管理人员向您问好�\�\n<br/>{sitename}','string','');
INSERT INTO aim_common_config VALUES('welcome.title','register','欢迎你注册成为{sitename}的会�\�','string','');
INSERT INTO aim_common_config VALUES('welcome.type','register','a:1:{i:0;s:1:\"1\";}','array','');
INSERT INTO aim_common_config VALUES('mobile.message.content','register','您的验证码是：{mobilecode}，请在页面填写验证码完成验证。（如非本人操作，可不予理会）【{sitename}�\�','string','');
INSERT INTO aim_common_config VALUES('cookie.domain','site','','string','');
INSERT INTO aim_common_config VALUES('cookie.path','site','','string','');
INSERT INTO aim_common_config VALUES('debug','site','0','string','');
INSERT INTO aim_common_config VALUES('info.name','site','Aimfive','string','');
INSERT INTO aim_common_config VALUES('managereasons','site','问题已收集，谢谢反馈�\�\n建议已收集，谢谢反馈�\�\n已关注，谢谢反馈�\�\n广告�\�\n恶意灌水\n非法内容\n与版规不�\�\n重复发帖\n------------------------------------------------\n优秀文章\n原创内容','string','');
INSERT INTO aim_common_config VALUES('onlinetime','site','30','string','');
INSERT INTO aim_common_config VALUES('punch.friend.open','site','1','string','');
INSERT INTO aim_common_config VALUES('punch.friend.reward','site','a:3:{s:9:\"friendNum\";d:3;s:11:\"rewardMeNum\";d:1;s:9:\"rewardNum\";d:1;}','array','');
INSERT INTO aim_common_config VALUES('punch.open','site','0','string','');
INSERT INTO aim_common_config VALUES('punch.reward','site','a:4:{s:4:\"type\";s:1:\"1\";s:3:\"min\";d:1;s:3:\"max\";d:5;s:4:\"step\";d:1;}','array','');
INSERT INTO aim_common_config VALUES('refreshtime','site','0','string','');
INSERT INTO aim_common_config VALUES('time.cv','site','0','string','');
INSERT INTO aim_common_config VALUES('time.timezone','site','8','string','');
INSERT INTO aim_common_config VALUES('visit.message','site','站点升级中。。�\�','string','');
INSERT INTO aim_common_config VALUES('content.length','verify','4','string','');
INSERT INTO aim_common_config VALUES('content.questions','verify','a:0:{}','array','');
INSERT INTO aim_common_config VALUES('content.showanswer','verify','0','string','');
INSERT INTO aim_common_config VALUES('content.type','verify','a:1:{i:0;s:1:\"3\";}','array','');
INSERT INTO aim_common_config VALUES('randtype','verify','a:3:{i:0;s:4:\"size\";i:1;s:5:\"angle\";i:2;s:5:\"graph\";}','array','');
INSERT INTO aim_common_config VALUES('showverify','verify','a:0:{}','array','');
INSERT INTO aim_common_config VALUES('type','verify','image','string','');
INSERT INTO aim_common_config VALUES('info.notice','site','','string','');
INSERT INTO aim_common_config VALUES('task.isOpen','site','0','string','');
INSERT INTO aim_common_config VALUES('attachnum','attachment','10','string','');
INSERT INTO aim_common_config VALUES('voice','verify','0','string','');
INSERT INTO aim_common_config VALUES('maxalbum','album','10','string','');
INSERT INTO aim_common_config VALUES('maxphoto','album','100','string','');
INSERT INTO aim_common_config VALUES('editor.style','bbs','1','string','');
INSERT INTO aim_common_config VALUES('content.duplicate','bbs','1','string','');
INSERT INTO aim_common_config VALUES('ubb.cvtimes','bbs','30','string','');
INSERT INTO aim_common_config VALUES('ubb.img.open','bbs','1','string','');
INSERT INTO aim_common_config VALUES('ubb.img.width','bbs','700','string','');
INSERT INTO aim_common_config VALUES('ubb.img.height','bbs','0','string','');
INSERT INTO aim_common_config VALUES('ubb.size.max','bbs','5','string','');
INSERT INTO aim_common_config VALUES('ubb.flash.open','bbs','0','string','');
INSERT INTO aim_common_config VALUES('ubb.media.open','bbs','0','string','');
INSERT INTO aim_common_config VALUES('ubb.iframe.open','bbs','0','string','');
INSERT INTO aim_common_config VALUES('medal.isopen','site','0','string','');
INSERT INTO aim_common_config VALUES('width','verify','240','string','');
INSERT INTO aim_common_config VALUES('height','verify','60','string','');
INSERT INTO aim_common_config VALUES('homeUrl','site','index.php?m=bbs','string','');
INSERT INTO aim_common_config VALUES('windid','site','local','string','');
INSERT INTO aim_common_config VALUES('homeRouter','site','a:3:{s:1:\"m\";s:3:\"bbs\";s:1:\"c\";s:5:\"index\";s:1:\"a\";s:3:\"run\";}','array','');
INSERT INTO aim_common_config VALUES('windid','windid','local','string','');
INSERT INTO aim_common_config VALUES('serverUrl','windid','http://aimfive.com/windid','string','');
INSERT INTO aim_common_config VALUES('clientId','windid','1','string','');
INSERT INTO aim_common_config VALUES('clientKey','windid','16582a0776b75aee0421aea9a6a93b60','string','');
INSERT INTO aim_common_config VALUES('connect','windid','db','string','');
INSERT INTO aim_common_config VALUES('avatarUrl','site','http://aimfive.com/windid/attachment','string','');
INSERT INTO aim_common_config VALUES('hash','site','TWlc3CBQ','string','');
INSERT INTO aim_common_config VALUES('cookie.pre','site','tGV','string','');
INSERT INTO aim_common_config VALUES('info.mail','site','admin@phpwind.com','string','');
INSERT INTO aim_common_config VALUES('info.url','site','http://aimfive.com','string','');
INSERT INTO aim_common_config VALUES('main','nav','a:1:{i:0;a:2:{s:4:\"name\";s:55:\"<a href=\"http://aimfive.com/index.php?m=bbs\">论坛</a>\";s:4:\"sign\";s:14:\"bbs|index|run|\";}}','array','');
INSERT INTO aim_common_config VALUES('bottom','nav','a:4:{i:0;a:2:{s:4:\"name\";s:88:\"<a href=\"http://www.phpwind.com/index.php?m=aboutus&a=index&menuid=16\">关于phpwind</a>\";s:4:\"sign\";s:0:\"\";}i:1;a:2:{s:4:\"name\";s:87:\"<a href=\"http://www.phpwind.com/index.php?m=aboutus&a=index&menuid=20\">联系我们</a>\";s:4:\"sign\";s:0:\"\";}i:2;a:2:{s:4:\"name\";s:72:\"<a href=\"http://www.phpwind.net/thread-htm-fid-39.html\">程序建议</a>\";s:4:\"sign\";s:0:\"\";}i:3;a:2:{s:4:\"name\";s:72:\"<a href=\"http://www.phpwind.net/thread-htm-fid-54.html\">问题反馈</a>\";s:4:\"sign\";s:0:\"\";}}','array','');
INSERT INTO aim_common_config VALUES('my','nav','a:5:{i:0;a:2:{s:4:\"name\";s:91:\"<a href=\"http://aimfive.com/index.php?m=space\"><em class=\"icon_space\"></em>我的空间</a>\";s:4:\"sign\";s:5:\"space\";}i:1;a:2:{s:4:\"name\";s:96:\"<a href=\"http://aimfive.com/index.php?m=my&c=fresh\"><em class=\"icon_fresh\"></em>我的关注</a>\";s:4:\"sign\";s:5:\"fresh\";}i:2;a:2:{s:4:\"name\";s:102:\"<a href=\"http://aimfive.com/index.php?m=bbs&c=forum&a=my\"><em class=\"icon_forum\"></em>我的版块</a>\";s:4:\"sign\";s:5:\"forum\";}i:3;a:2:{s:4:\"name\";s:100:\"<a href=\"http://aimfive.com/index.php?m=my&c=article\"><em class=\"icon_article\"></em>我的帖子</a>\";s:4:\"sign\";s:7:\"article\";}i:4;a:2:{s:4:\"name\";s:94:\"<a href=\"http://aimfive.com/index.php?m=vote&c=my\"><em class=\"icon_vote\"></em>我的投票</a>\";s:4:\"sign\";s:4:\"vote\";}}','array','');
INSERT INTO aim_common_config VALUES('info.icp','site','','string','');
INSERT INTO aim_common_config VALUES('info.logo','site','','string','');
INSERT INTO aim_common_config VALUES('statisticscode','site','','string','');
INSERT INTO aim_common_config VALUES('theme.site.pack','site','site','string','');
INSERT INTO aim_common_config VALUES('theme.site.default','site','default','string','');
INSERT INTO aim_common_config VALUES('theme.space.pack','site','space','string','');
INSERT INTO aim_common_config VALUES('theme.space.default','site','default','string','');
INSERT INTO aim_common_config VALUES('theme.forum.pack','site','forum','string','');
INSERT INTO aim_common_config VALUES('theme.forum.default','site','default','string','');
INSERT INTO aim_common_config VALUES('theme.portal.pack','site','portal/appcenter','string','');
INSERT INTO aim_common_config VALUES('visit.state','site','2','string','');
INSERT INTO aim_common_config VALUES('visit.group','site','','string','');
INSERT INTO aim_common_config VALUES('visit.gid','site','','string','');
INSERT INTO aim_common_config VALUES('visit.ip','site','','string','');
INSERT INTO aim_common_config VALUES('visit.member','site','','string','');
INSERT INTO aim_common_config VALUES('seo_bbs_thread_1','seo','a:6:{s:3:\"mod\";s:3:\"bbs\";s:4:\"page\";s:6:\"thread\";s:5:\"param\";s:1:\"1\";s:5:\"title\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";}','array','');
INSERT INTO aim_common_config VALUES('seo_bbs_thread_2','seo','a:6:{s:3:\"mod\";s:3:\"bbs\";s:4:\"page\";s:6:\"thread\";s:5:\"param\";s:1:\"2\";s:5:\"title\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";}','array','');



